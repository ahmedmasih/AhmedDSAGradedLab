package driver;

import java.util.Scanner;

public class driver {

	public static void main(String[] args) {

		System.out.println("Enter the size of transaction array");
		Scanner sc = new Scanner(System.in);
		int arr_size = 0;
		int targetCount = 0;
		if (sc.hasNextInt()) {
			arr_size = sc.nextInt();
		}
		// Initialize the array's
		// size using user input
		int[] arr = new int[arr_size];

		// Take user elements for the array
		System.out.println("Enter the values of array: ");
		for (int i = 0; i < arr_size; i++) {
			if (sc.hasNextInt()) {
				arr[i] = sc.nextInt();
			}
		}
		System.out.println("enter the total no of targets that needs to be achieved");
		if (sc.hasNextInt()) {
			targetCount = sc.nextInt();
		}
		int count = 0;
		
		while (targetCount != 0) {
			++count;
			long target = 0;
			System.out.println(" Enter the " + count + " value  of the target ");
			target = sc.nextInt();
			long sum = 0;

			for (int i = 0; i <= arr_size; i++) {
				sum += arr[i];
				int j = 0;
				if (sum >= target) {
					j = i + 1;
					System.out.println("Target is achieved after " + j + " transactions");
			
					break;
				} else  {
					if(i==arr.length-1) {
				
					System.out.println("Target not achieved ");
				}
			}
			

		}
			targetCount = targetCount - 1;
		}

	}

}
