package driver;
import java.util.Scanner;
import java.util.Arrays;
public class currency {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

        // Take input for currency denominations
        System.out.print("Enter the size of currency denominations: ");
        int size = sc.nextInt();
        int[] denominations = new int[size];
        System.out.println("Enter the currency denominations value:");
        for (int i = 0; i < size; i++) {
            denominations[i] = sc.nextInt();
        }

        // Take input for the amount to be paid
        System.out.print("Enter the amount you want to pay: ");
        int amount = sc.nextInt();

        // Sort the denominations in descending order
        Arrays.sort(denominations);
        reverseArray(denominations);

        // Calculate the minimum number of notes required
        int[] count = new int[size];
        for (int i = 0; i < size; i++) {
            count[i] = amount / denominations[i];
            amount %= denominations[i];
        }

        // Print the payment approach
        System.out.println("Your payment approach in order to give the minimum number of notes will be:");
        for (int i = 0; i < size; i++) {
            if (count[i] > 0) {
                System.out.println(denominations[i] + ":" + count[i]);
            }
        }
    }

    // Helper method to reverse an array
    private static void reverseArray(int[] arr) {
        int start = 0;
        int end = arr.length - 1;
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
		// TODO Auto-generated method stub

	}

}
